<html>
<head>



<style>

</style>
</head>
<body>
<form action="next.php" method="GET">  

First Name:<input type="text" name="fname"><br>

Email:<input type="text" name="email"><br>

Credit Card:<input type="text" name="cc"><br>

<button type="submit">Go!!</button>

</form>
</body
</html>


<?php
//check if cc is 16 digits

$cc = "4537339827500014";

$total = 0;

if(strlen($cc) == 16){
	echo"Yeah...16digits".$cc."<br>";
	
	//reversing the loop
	
	$Reversed = strrev($cc);
	echo"here is it:".$Reversed;
	
	


	//1. loop through the numbers in the cc
	for($i=0;$i<16;$i++){
		//@debug: print each charatcter
		
		echo $Reversed[$i];
	
	//2. if position odd
		//a. multiply by 2
		//b. if multiply >9 ,then convert otherwise, do nothing
		
	
			if($i%2==1){
			//do multiply + covert
			$num = $Reversed[$i]*2;
			
			if($num>9){
				$num = $num - 9;
			}
		}else{
			$num = $Reversed[$i];
		}
		echo "converted number:" .$num."<br>";
			
		
	//3.addd to totaal
	$total= $total + $num;
	
	echo $total;
	
		
}

//4.after looping,do total % 10

    if($total%10==0){
		
		
		echo"its valid"."<br>";
	}
	//5.if total %10 == 0,winner!!!!
	
	else{
		echo"noooo";
	}
}
else{
	echo"nahhhhh...make it 16 digits";
}



?>