<h1> Hello <h1>
<h2> This is my Page </h2>

<?php


//build a program to check if person came to this page usinf get or post request


//most output
//echo"hey.<br>";

//array aoutput
//print_r($_SERVER)

/*
if ($_SERVER["REQUEST_METHOD"]=="POST"){
	echo"post";
}
else if($_SERVER["REQUEST_METHOD"]=="GET"){
	echo"get";
}
*/

echo"whats in the get";
print_r($_GET);

if ($_SERVER["REQUEST_METHOD"]=="GET"){
	echo"The student NAme is :" .$_GET["studentName"]."<br>";
echo"ID is:" .$_GET["id"]."<br>";
}

echo"whats in the post";
print_r($_POST);

if ($_SERVER["REQUEST_METHOD"] == "POST"){
		echo "The student is: " . $_POST["studentName"] . "<br>";
		echo "The id is: " . $_POST["id"] . "<br>";
	}



?>