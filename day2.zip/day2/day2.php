
<html>
<head>



<style>

</style>
</head>
<body>


<h1> Put and Get Requests </h1>


<form action="next.php" method="POST">    
<?   with GET u will get ? nd with POST nothing in googgle crome  ?>

Name:<input type="text" name="studentName"><br>

ID:<input type="text" name="id"><br>




	<button type="submit">Go!!</button>


</form>
</body
</html>