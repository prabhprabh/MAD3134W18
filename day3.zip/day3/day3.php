<?php
 if($_SERVER["REQUEST_METHOD"] == "GET"){
 }
else if($_SERVER["REQUEST_METHOD"] == "POST"){
	$guess = $_POST["guess"];
	echo $guess ."<br>";
	if($guess == $password){
		echo "winner";
	}else{
		$correct = 0;
		for($i = 0;$i<4;$i++){
			if($guess[$i]==$password[$i]){
				$correct = $correct+1;
			}
		}
	}
 }

 
 
 
	//read word from file
		$file= file_get_contents("simplewords.txt",true);
		$words = str_word_count($file, 1);
		
		print_r($words);
		
		
	//randomly pick words from array
	
	//print_r(array_rand($words, 10));

	
	//get length of array
	$length = count($words);
	//$randomNumber = rand ( int $min , int $max );
	$position = [];  //put all positions in this array
	$choices =[];   //10 randomly choosen words
	$picked = [];    //put all positions in this array
	
	for ($i=0;$i<10;$i++){
		while(1) {
		
			//position check
			$randomNumber = rand (0 ,$length-1);
			
			if(in_array($randomNumber, $picked) == true){
				//skip
				continue;
			}
			else{
				
			//if you picked the position alreday,
			//thn pic new random no.
				array_push($choices, $words[$randomNumber]);
				break;
			}
		}	
		
		echo $words[$randomNumber]."<br>";
		
	}

	//pick password
//option 1. $x = rand(00,count($choices)-1)
//option 2. $x = rand(0,1);
$x = rand(0,count($choices)-1);
$password = $choices[$x];
for($j=0;$j<count[$choices];$j++){
	echo $simplewords[$randomnumber]."<br>";
}
echo "password :" .$password ."<br>";


	
	
	
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hello Bulma!</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
	
    <script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
  </head>
  <body style="font-family: 'Indie Flower', cursive;">
 
      
<label>Enter Password</label>
<input type="text" name="guess">
<button> Go..!!</button>	  
	 
	
  
 
  
  </body>
</html>