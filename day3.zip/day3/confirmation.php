

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hello Bulma!</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
  </head>
  <body>
  <section class="section">
    <div class="container">
      <h1 class="title">
        
		Order Confirmation
		
      </h1>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  <?php
//logic goes here....

//print_r ($_POST);

// test fr error conditions..

//check if fields are blank

$name = $_POST["name"];
$email = $_POST["email"];
$cc = $_POST["cc"];


if (empty($name) || empty($email) || empty($cc)){
	
	echo "<br>"."blank";
	//return;  //stop execution of page
	//die();
	//exit();
}

//cc pass 

if(ccIsValid($cc)==false){
	echo "<br>"."Credit Card is invalid"."<br>";
}

function ccIsValid($cc){
	$total = 0;

	$cc = $_POST["cc"];

	if(strlen($cc) == 16){
	//echo"Yeah...16digits".$cc."<br>";
	
	//reversing the loop
	
	$Reversed = strrev($cc);
	//echo"here is it:".$Reversed;
	
	


	//1. loop through the numbers in the cc
	for($i=0;$i<16;$i++){
		//@debug: print each charatcter
		
		//echo $Reversed[$i];
	
	//2. if position odd
		//a. multiply by 2
		//b. if multiply >9 ,then convert otherwise, do nothing
		
	
			if($i%2==1){
			//do multiply + covert
			$num = $Reversed[$i]*2;
			
			if($num>9){
				$num = $num - 9;
			}
		}else{
			$num = $Reversed[$i];
		}
	//	echo "converted number:" .$num."<br>";
			
		
	//3.addd to totaal
	$total= $total + $num;
	
	//echo $total;
	
		
}

//4.after looping,do total % 10

    if($total%10==0){
		
		
		return true;
	}
	//5.if total %10 == 0,winner!!!!
	
	else{
		return false;
	}
}
	

	
}  //end of function




/*
//checking 16 digit

$cc = $_POST["cc"];
if (strlen($cc) != 16){

}	


//another way

if (strlen($_POST["cc"] != 16)
	
	{
	 echo"error";	
	}
	
	
//another way to check if blank..





//exmaple 1
$y="lol";
if(empty($y)){
	
	
}

//example 2
$x="hii";
if($x=""){
	
	
}
*/

//check if credit card is valid

		//a. cehck if cc is 16 digits
		
		//b.doe scc pass the algo



//if pass,then show success message..

if(ccIsValid($cc)==true){

echo "Hey,".$name."<br>";
echo"Thank you for your information"."<br>";
echo"We sent a copy of your receipt to ".$email."<br>"; 

}


?>




	  
	  
	  
	 
      <a href="checkout.php" > Go Back </a>
    </div>
  </section>
  </body>
</html>