<h1> Prabh </h1>

//comment//  this does not work in here....
<?   comment      ?>



<?php


//your code goes here

//Basics


//comment  this works inside php

$x=25;  //creating var in php //no spacing 

$y="prabh";

$z=44.4;

$love = $x;

echo $love;  //output_add_rewrite_var

echo "<h2> $y </h2>";

echo "<h2> prabh </h2>";

echo "hi"."my"."name"."is"."prabh";
 
echo $x + $z;

$abc = 30;

if($abc>30){ // if statenebts are same
	echo"yes";
}
else if($abc=30){
	echo"maybe";
}
	else{
		echo"no";
	}

	//for loop--- repeats fixed no of time---we tell how many times you wanna loop to repaat
	//while loop--- loop reapats until condition matches annd doesnt stop until itmatches
	
	for($i=0;$i<5; $i++){
		echo"hey <br>";  //use <br> for new line
	}
	
	$b = 5;
	while($b<8){
		echo "nahhhh <br>";
		$b = $b +1;   //to stop while loop
	}
	
	
	//$c = 5;
	//while($c>4){
		//echo "hannnnn <br>";
		//$b = $b +1;   //to stop while loop
	//}
	
	//creating fn
	function hello(){
		echo"heyeyeyeeeeyyee <br>";
	}
	//using function
	hello();
	
	function fruit($name, $price){
		
	}
	
	function fruits($language){
		if($language =="punjabi" || $language == "hindi"){
			echo"saibb";
		}
		else if($language == "english"){
			echo"Apple";
		}
		else if($language == "french"){
			echo"Pomme";
		}
		
	}
	
	//using functions
	
	$w = "punjabi";
	fruits($w);
	
	
	//Arrays
	
	$animal = [];
	$animals=array();
	
	//adding things to array
	$animals[0]="dog";
	$animals[1]="cat";
	
	//another way to add array
	array_push($animals,"fox");
	
	//how to get lenghth of array
	echo"lenght is: " .count($animals). "<br>";
	
	
	for($j =0; $j< 8;$j++){
		array_push($animals,"cow");
		echo "hey: " .$animals[$j]. "<br>";
	}
	
	//output ana array
	print_r($animals);
	
	//associative array --dictionary
	
	$easy =array(
	"eng" => "easy",
	"french" => "facile",
	"vet" => "de",
	"pun" => "sokha",
	"guj" => "saral"
	);
	
	
	print_r($easy);
	
	i
	echo $easy["eng"]."<br>";
	//sytax
	//foreach(----as---- => ----){
		
		
	//}
	
	foreach($easy as $k => $v){
		echo "Key is:".$k."<br>";
		echo "value	is:".$v."<br>";
		echo "----:"."<br>";
	}
?>