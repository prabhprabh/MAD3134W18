<?php
	include("header.php");
?>

    <!-- BACKPACKS and BAGS -->
    <section class="section">
      <div class="container">
        <h1 class="title">Backpacks & Bags</h1>
        <h2 class="subtitle">
          A selection of awesome backpacks for your everyday commute.
        </h2>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <!-- put your products in here -->
      </div>
    </section>
	<script type="text/javascript">
    </script>
  </body>
</html>
