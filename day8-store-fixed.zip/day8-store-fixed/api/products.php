<?php

echo "Hey ";
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpassword = "";
	$dbname = "store";

	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

	$query = "SELECT * from products";
	
	$results = mysqli_query($conn, $query);

	//print_r($results);
	
	$stores=array();
	while( $item = mysqli_fetch_assoc($results) ) {
		//add items to array
	array_push($stores, $item);
	
	//print_r($stores);
		
	}
	
	//return all licatiobs as json_decode
	
	//tell browser we're sending json_decode
	header("Content-Type:application/json");
	
	//convert our array into json dictionary
	$json=json_encode($stores);
	
	//deal with nay erriors during conversion
	if ($json === false){
		$errorMessage = array("error"=>json_last_error_msg());
		$json=json_encode($json);
		http_response_code(500);
	}
	
	//send json dictionary to browser
	echo $json;
	




?>