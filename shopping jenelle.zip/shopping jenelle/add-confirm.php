<?php
	//@TODO: Put your PHP logic here
	
	$name = $_POST["pname"];
	$desc = $_POST["desc"];  //form names
	$price = $_POST["price"];
	
	
	//connect db
	$dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "shopping";
	
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
	
	//run query
	
	
	$query = 
'INSERT INTO product (Name, Description, Price) ' .
'VALUES ("' .$name . '","' . $desc . '","' . $price . '")'; //table names
	
	//make sql query
	
	//get result
	$results = mysqli_query($conn, $query);

	
	
	
print_r($_POST);
?>
<!DOCTYPE html5>
<html>
<head>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
	<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
	<style type="text/css">
		.mdl-grid {
			max-width:1024px;
			margin-top:40px;
		}
		
		h1 {
			font-size:36px;
		}
		h2 {
			font-size:30px;
		}
	</style>

</head>
<body>

	<div class="mdl-grid">
	  <div class="mdl-cell mdl-cell--12-col">
		<p> Put some messages here? </p>
		
		<a href="show-products.php" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
			< Go Back 
		</a>
	  </div>
	</div>
	
</body>
</html>